import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    city = ""
    while True:
        print("Would you like to see data for Chicago, New York City, or Washington?")
        #converting user input into lower
        city = input().lower()
        if city in CITY_DATA:
            break
         
        else:
            print("\nYour city is not in data, Please enter valid city ")

    # get user input for month (all, january, february, ... , june)
    months = ["all", "january", "february", "march", "april", "may", "june"]
    month = ""
    while True:
        print("\nWhich month? Choose from January to June or all")
        month = input().lower()
        if month in months:
            break
        else:
            print("\nYour month is not in data, Please enter valid month")

    # get user input for day of week (all, monday, tuesday, ... sunday)
    days = ["all", "Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    day = ""
    while True:
        print("\nWhich day? Choose from Saturday to Friday or all")
        day = input().lower()
        if day in days:
            break
        else:
            print("\nYour day is not in data, please enter valid value as integer only")
   
    print('-'*40)
    return city, month, day

def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    #load data file for user city
    df = pd.read_csv(CITY_DATA[city])

    #connvert the start time to datetime then extract month and day of week to create new columns
    df["Start Time"] = pd.to_datetime(df["Start Time"])
    df["month"] = df["Start Time"].dt.month
    df["day_of_week"] = df["Start Time"].dt.day
    
    #filter by month
    if month != "all":
        months = ["january", "february", "march", "april", "may", "june"]
        month = months.index(month) + 1

        #filter by month to create new datetime
        df = df[df["month"] == month]
    
    #filter by day
    if day != "all":
        #filter by day to create new datetime
        df = df[df["day_of_week"] == day]

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    common_month = df["month"].mode()[0]
    print("The most common month is",common_month)

    # display the most common day of week
    common_day = df["day_of_week"].mode()[0]
    print("The most common day is",common_day)

    # display the most common start hour
    df["Start Hour"] = df["Start Time"].dt.hour
    common_hour = df["Start Hour"].mode()[0]
    print("The most common start hour is",common_hour)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    common_start_station = df["Start Station"].mode()[0]
    print("The most commonly used start station is",common_start_station)

    # display most commonly used end station
    common_end_station = df["End Station"].mode()[0]
    print("The most commonly used end station is",common_end_station)

    # display most frequent combination of start station and end station trip
    df["combination"] = df["Start Station"]+ " "+"to"+" "+ df["End Station"]
    frequent_combination = df["combination"].mode()[0]
    print("The most frequent combination os Start and End Station is",frequent_combination)
    

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time by sum
    total_travel_time = df["Trip Duration"].sum()
    #in minutes and seconds format
    minute, second = divmod(total_travel_time,60)
    #in hours and minutes format
    hour, minute = divmod(minute,60)
    print("The total travel time is {} hour(s) {} minute(s) {} second(s)".format(hour, minute, second))

    # display mean travel time
    mean_travel_time = round(df["Trip Duration"]).mean()
    min, sec = divmod(mean_travel_time,60)
    if min > 60:
        hr, min = divmod(min,60)
        print("The mean (average) travel time is {} hour(s) {} minute(s) {} second(s)".format(hr, min, sec))
    else:
        print("The mean (average) travel time is {} minute(s) {} second(s)".format(min, sec))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_type = df["User Type"].value_counts()
    print("The counts of user type are\n",user_type)

    # Display counts of gender
    try:
        gender = df["Gender"].value_counts()
        print("The counts of gender are\n",gender)
    except:
        print("There is no Gender in Washington File")

    # Display earliest, most recent, and most common year of birth
    try:
        earliest = int(df["Birth Year"].min())
        print("\nThe earliest year of birth:",earliest)
        most_recent = int(df["Birth Year"].max())
        print("\nThe most recent year:",most_recent)
        most_common_year = int(df["Birth Year"].mode()[0])
        print("\nThe most common year:",most_common_year)
    except:
        print("There is no Birth Year in Washington File")

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def display_data(df):
    """Displays statistics on bikeshare users."""

    start_loc = 0
    e_loc = 5

    view_data = input("\nWould you like to view 5 rows of individual trip data? Enter yes or no\n ").lower()

    if view_data == 'yes':
        while e_loc <= df.shape[0] - 1:
            print(df.iloc[start_loc:e_loc,:])
            start_loc += 5
            e_loc += 5

            end_display = input("Do you wish to continue?: ").lower()
            if end_display == 'no':
                break

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
	main()